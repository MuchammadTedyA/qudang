<?php $__env->startSection('judul'); ?>
  Data Barang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <?php if(Session::has('message')): ?>
    <script>
        alert("<?php echo Session::get('message'); ?>");
      </script>
    <?php endif; ?>
    <div class="">
      <a href="tambahBarang" class="btn btn-primary" style="margin: 20px">Tambah Barang</a>
      <div class="table-responsive">
        <table class="table table-striped table-hover">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Barang</th>
              <th>Satuan</th>
              <th>Stok</th>
              <th>Deskripsi</th>
              <th>Action</th>

            </tr>
          </thead>
          <tbody>
            <?php $no=1 ?>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($no++); ?></td>
              <td><?php echo e($item->nama_barang); ?></td>
              <td><?php echo e($item->satuan); ?></td>
              <td><?php echo e($item->stok); ?></td>
              <td><?php echo e($item->deskripsi); ?></td>
              <td><a class="btn btn-danger" href="hapusBarang/<?php echo e($item->id_barang); ?>">Hapus</a>&nbsp;&nbsp;<a class="btn btn-warning" href="formeditBarang/<?php echo e($item->id_barang); ?>">Edit</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qudang\resources\views/dataBarang.blade.php ENDPATH**/ ?>